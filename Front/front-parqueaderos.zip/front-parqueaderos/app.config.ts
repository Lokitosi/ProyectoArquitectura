export default defineAppConfig({
    title:'Sistema de parqueaderos',
    theme:{
        dark:true,
        colors:{
            primary: '#ff0000',
            secondary: '#ffffff',
        }
    }
})